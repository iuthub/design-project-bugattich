Instructions for using!


Log in for Admin Dashboard
Email:
admin@admin.com
Password:
admin


Log in for Admin Dashboard
Email:
employee@employee.com
Password:
employee




Group
Members
Akmaljon Abdullajonov - U1610017
Avazbek Sirojiddinov - U1610029
Bekhuz Yarkulov - U1610045
Jasur Akhmedov - U1610093
Khusan Davlatov - U1610114


